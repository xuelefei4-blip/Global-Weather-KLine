import os
import subprocess
import sys
from datetime import datetime

# 设置控制台输出编码
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

# 定位项目根目录 (即包含 .git 的 Global-Weather-KLine 目录)
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, ".."))

def log(msg, color="32"):
    print(f"\033[{color}m{msg}\033[0m")

def run_git_cmd(cmd, cwd):
    print(f">> 执行: {' '.join(cmd)}")
    result = subprocess.run(
        cmd,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace"
    )
    if result.stdout:
        print(result.stdout.strip())
    return result.returncode == 0

def ensure_gitignore():
    """确保 .gitignore 严格忽略 MeteoOps 等私有运维目录"""
    gitignore_path = os.path.join(PROJECT_ROOT, ".gitignore")
    ignore_rules = [
        "MeteoOps/",
        "MeteoOps/**",
        "*.pyc",
        "__pycache__/",
        ".vscode/"
    ]
    
    existing_rules = []
    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r", encoding="utf-8") as f:
            existing_rules = [line.strip() for line in f.readlines()]

    needs_update = False
    with open(gitignore_path, "a", encoding="utf-8") as f:
        for rule in ignore_rules:
            if rule not in existing_rules:
                f.write(f"\n{rule}")
                needs_update = True

    if needs_update:
        log("🛡️ .gitignore 安全规则已更新，彻底阻断 MeteoOps 泄露。", "36")

def main():
    log("====================================================", "34")
    log("🚀 [MeteoOps] 开始执行自动化 GitHub 发布流程...", "34")
    log(f"📂 仓库根目录: {PROJECT_ROOT}")
    log("====================================================", "34")

    # 1. 检查是否为 git 仓库
    if not os.path.exists(os.path.join(PROJECT_ROOT, ".git")):
        log("❌ 错误: 项目根目录未检测到 .git 仓库，请先执行 git init！", "31")
        sys.exit(1)

    # 2. 安全检查与保护
    ensure_gitignore()

    # 3. 如果之前不慎加入了 MeteoOps 缓存，再次安全清理
    run_git_cmd(["git", "rm", "-r", "--cached", "MeteoOps"], cwd=PROJECT_ROOT)

    # 4. 暂存所有静态资源、HTML 及数据变更
    log("📦 正在暂存文件 (git add)...", "33")
    if not run_git_cmd(["git", "add", "."], cwd=PROJECT_ROOT):
        log("❌ 暂存变动失败", "31")
        sys.exit(1)

    # 5. 检查是否有变动需要提交
    status_proc = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=PROJECT_ROOT,
        stdout=subprocess.PIPE,
        text=True,
        encoding="utf-8"
    )

    if not status_proc.stdout.strip():
        log("ℹ️ 工作区干净，没有检测到任何新变更，无需推送！", "33")
        return

    # 6. 生成规范提交说明
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    commit_msg = f"chore(data): auto sync meteorological data update [{now_str}]"
    
    log(f"📝 正在提交: {commit_msg}", "33")
    if not run_git_cmd(["git", "commit", "-m", commit_msg], cwd=PROJECT_ROOT):
        log("❌ Git Commit 失败", "31")
        sys.exit(1)

    # 7. 检测主分支名称 (main 或 master)
    branch = "main"
    branch_check = subprocess.run(
        ["git", "branch", "--show-current"],
        cwd=PROJECT_ROOT,
        stdout=subprocess.PIPE,
        text=True,
        encoding="utf-8"
    )
    if branch_check.stdout.strip():
        branch = branch_check.stdout.strip()

    # 8. 推送到远程
    log(f"🚀 正在推送到 GitHub 远程仓库 ({branch})...", "35")
    if run_git_cmd(["git", "push", "origin", branch], cwd=PROJECT_ROOT):
        log("====================================================", "32")
        log("🎉 ✅ 恭喜！最新气象数据已成功发布至 GitHub！", "32")
        log("====================================================", "32")
    else:
        log("❌ 推送至远程仓库失败，请检查网络连接或 GitHub SSH/Token 认证状态！", "31")
        sys.exit(1)

if __name__ == "__main__":
    main()