@echo off
title MeteoOps 气象控制台服务
echo ===================================================
echo   MeteoOps 全球气象运维中台 正在启动...
echo   服务启动后将自动弹出网页，请勿关闭本窗口！
echo ===================================================
echo.

python server.py
pause